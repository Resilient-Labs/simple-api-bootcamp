document.querySelector('button').addEventListener('click', getData)

function getData(){
  let pokemon = document.querySelector('input').value

  let apilink =`https://pokeapi.co/api/v2/pokemon/${pokemon}`
  
  fetch(apilink)
    .then(res => res.json()) 
    .then(data => {

         document.querySelector('h2').innerText = data.species.name
         document.querySelector('img').src = data.sprites.front_shiny
        // document.querySelector('h3').innertext = data.explanation
        console.log(data)
    
    })
    .catch(err =>{
    console.log('error' + err);

    })

}
